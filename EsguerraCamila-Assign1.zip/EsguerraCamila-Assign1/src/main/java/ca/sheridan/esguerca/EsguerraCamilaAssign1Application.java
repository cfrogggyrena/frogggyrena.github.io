package ca.sheridan.esguerca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsguerraCamilaAssign1Application {

	public static void main(String[] args) {
		SpringApplication.run(EsguerraCamilaAssign1Application.class, args);
	}

}
